import 'package:flutter/material.dart';

const List<Color> colorPalette = [
  Color.fromARGB(255, 255, 255, 255),
  Color.fromARGB(255, 65, 62, 143),
  Color.fromARGB(255, 67, 104, 80),
  Color.fromARGB(255, 152, 94, 176),
  Color.fromRGBO(15, 14, 14, 1),
];
